# CheckMaadsi v3 — Home Inspection Report Builder

A production-ready Next.js 14 App Router scaffold for generating professional home inspection reports in Indian real estate.

---

## Tech stack

| Layer        | Choice                                     |
|--------------|--------------------------------------------|
| Framework    | Next.js 14 (App Router)                    |
| Language     | TypeScript (strict)                        |
| Forms        | React Hook Form + Zod                      |
| Styling      | Tailwind CSS v3                            |
| Icons        | Lucide React                               |
| Data (v3)    | In-memory store via localStorage           |
| Data (prod)  | Replace `lib/store.ts` with Supabase / PlanetScale |

---

## Quick start

```bash
# 1. Install dependencies
npm install

# 2. Run dev server
npm run dev

# 3. Open http://localhost:3000
```

---

## Project structure

```
app/
  layout.tsx              Root layout + nav
  page.tsx                Landing / home page
  globals.css             Tailwind base + print styles
  dashboard/page.tsx      All saved reports
  inspection/new/page.tsx 3-step inspection wizard
  report/[id]/page.tsx    Printable report view

components/
  ui.tsx                  Primitive UI (Button, Card, Input, Badge, etc.)
  nav.tsx                 Top navigation bar
  property-form.tsx       React Hook Form + Zod metadata form
  inspection-section.tsx  Collapsible section with status radios + comments
  summary-panel.tsx       Issue count + sorted findings
  report-view.tsx         Print-ready report component

lib/
  types.ts                TypeScript domain types
  schemas.ts              Zod validation schemas
  utils.ts                cn(), status maps, getFlatFindings(), countBySeverity()
  store.ts                localStorage persistence (swap for DB in production)

data/
  apartment-handover.json Apartment handover checklist template
  villa-inspection.json   Villa inspection template (starter)
```

---

## Inspection template format

Templates live in `data/*.json`. Add more by creating a new JSON file and importing it in the page.

```json
{
  "templateId": "apartment-handover-v1",
  "name": "Apartment handover",
  "sections": [
    {
      "id": "finishes",
      "title": "Finishes & surfaces",
      "description": "Short description for inspector",
      "items": [
        {
          "key": "wallCracks",
          "label": "Wall cracks and patchwork",
          "note": "Check for visible cracks, bulges and poor putty application.",
          "severityDefault": "ok"
        }
      ]
    }
  ]
}
```

---

## Production roadmap

### Phase 1 — Database
- Replace `lib/store.ts` with Supabase client
- Add `reports` and `findings` tables
- Use Next.js Server Actions for save / update / delete

### Phase 2 — Auth
- Add Clerk or NextAuth
- Inspector login and client-facing read-only report link

### Phase 3 — Photos
- Add file input per inspection item
- Upload to S3 with presigned URLs
- Render photos in report

### Phase 4 — PDF export
- Add `/api/report/[id]/pdf` route
- Use Puppeteer or Browserless to render the report page as PDF
- Stream PDF to client

### Phase 5 — Advanced
- Reusable comment templates for common defects
- Digital signature on final report
- WhatsApp / email delivery of report link
- Multi-inspector support
- Offline PWA mode for on-site inspections
