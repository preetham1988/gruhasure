'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import type { InspectionReport } from '@/lib/types'
import { getAllReports, deleteReport } from '@/lib/store'
import { Button, Card, Badge } from '@/components/ui'
import { countBySeverity } from '@/lib/utils'

export default function Dashboard() {
  const [reports, setReports] = useState<InspectionReport[]>([])

  useEffect(() => { setReports(getAllReports()) }, [])

  function handleDelete(id: string) {
    if (!confirm('Delete this report?')) return
    deleteReport(id)
    setReports(getAllReports())
  }

  return (
    <div>
      <div className="flex items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-display font-semibold">All reports</h1>
          <p className="text-gray-500 dark:text-zinc-400 text-sm mt-1">{reports.length} report{reports.length !== 1 ? 's' : ''} saved</p>
        </div>
        <Link href="/inspection/new"><Button>New inspection</Button></Link>
      </div>

      {reports.length === 0 ? (
        <Card className="text-center py-16">
          <p className="text-4xl mb-4">📋</p>
          <h2 className="text-xl font-semibold mb-2">No reports yet</h2>
          <p className="text-gray-500 dark:text-zinc-400 text-sm mb-6">Start your first inspection to see it here.</p>
          <Link href="/inspection/new"><Button>Start inspection</Button></Link>
        </Card>
      ) : (
        <div className="grid gap-4">
          {reports.map(report => {
            const counts = countBySeverity(report)
            return (
              <Card key={report.id} className="flex flex-col md:flex-row justify-between gap-4 p-5">
                <div>
                  <h2 className="font-semibold">{report.meta.propertyName}</h2>
                  <p className="text-sm text-gray-500 dark:text-zinc-400">{report.meta.unitNumber} · {report.meta.clientName} · {report.meta.inspectionDate}</p>
                  <div className="flex gap-2 mt-2 flex-wrap">
                    {counts.major > 0    && <Badge status="major" />}
                    {counts.minor > 0    && <Badge status="minor" />}
                    {counts.attention > 0 && <Badge status="attention" />}
                  </div>
                </div>
                <div className="flex gap-2 items-start">
                  <Link href={`/report/${report.id}`}><Button variant="secondary">View report</Button></Link>
                  <Button variant="ghost" onClick={() => handleDelete(report.id)} className="text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20">Delete</Button>
                </div>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
