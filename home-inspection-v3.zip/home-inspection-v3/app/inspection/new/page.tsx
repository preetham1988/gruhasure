'use client'

import { useState, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import type { InspectionTemplate, FindingRecord, PropertyMeta } from '@/lib/types'
import type { PropertyMetaSchema } from '@/lib/schemas'
import { saveReport } from '@/lib/store'
import { PropertyForm } from '@/components/property-form'
import { InspectionSectionCard } from '@/components/inspection-section'
import { SummaryPanel } from '@/components/summary-panel'
import { Button, Card } from '@/components/ui'
import templateData from '@/data/apartment-handover.json'

const template = templateData as InspectionTemplate

const STEPS = ['Setup', 'Inspect', 'Summary'] as const
type Step = typeof STEPS[number]

export default function NewInspection() {
  const router = useRouter()
  const [step, setStep] = useState<Step>('Setup')
  const [meta, setMeta] = useState<PropertyMeta | null>(null)
  const [findings, setFindings] = useState<Record<string, FindingRecord>>({})

  const handleMetaSubmit = (data: PropertyMetaSchema) => {
    setMeta(data as PropertyMeta)
    setStep('Inspect')
  }

  const handleFindingChange = useCallback((key: string, patch: Partial<FindingRecord>) => {
    setFindings(prev => ({ ...prev, [key]: { status: 'ok', comment: '', ...prev[key], ...patch } }))
  }, [])

  const handleSave = () => {
    if (!meta) return
    const report = saveReport({ meta, templateId: template.templateId, findings })
    router.push(`/report/${report.id}`)
  }

  const stepIdx = STEPS.indexOf(step)

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-display font-semibold mb-4">New inspection</h1>
        <div className="flex gap-2">
          {STEPS.map((s, i) => (
            <button key={s} onClick={() => i < stepIdx && setStep(s)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold border transition-colors ${
                s === step ? 'bg-primary text-white border-primary' :
                i < stepIdx ? 'bg-primary/10 text-primary border-primary/30 cursor-pointer' :
                'text-gray-400 dark:text-zinc-500 border-gray-200 dark:border-zinc-800 cursor-default'
              }`}>
              <span className={`w-5 h-5 rounded-full text-xs flex items-center justify-center ${
                s === step ? 'bg-white/20' : i < stepIdx ? 'bg-primary/20' : 'bg-gray-200 dark:bg-zinc-700'
              }`}>{i + 1}</span>
              {s}
            </button>
          ))}
        </div>
      </div>

      {step === 'Setup' && <PropertyForm onSubmit={handleMetaSubmit} />}

      {step === 'Inspect' && (
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            {template.sections.map(section => (
              <InspectionSectionCard
                key={section.id}
                section={section}
                findings={findings}
                onChange={handleFindingChange}
              />
            ))}
          </div>
          <div className="space-y-4">
            {meta && <SummaryPanel report={{ id: '', createdAt: '', meta, templateId: template.templateId, findings }} template={template} />}
            <Card className="p-5">
              <p className="text-sm text-gray-500 dark:text-zinc-400 mb-4">Finished all sections? Generate the report.</p>
              <Button className="w-full justify-center" onClick={() => setStep('Summary')}>Review summary →</Button>
            </Card>
          </div>
        </div>
      )}

      {step === 'Summary' && meta && (
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <SummaryPanel report={{ id: '', createdAt: '', meta, templateId: template.templateId, findings }} template={template} />
          </div>
          <Card className="p-5 space-y-3 h-fit">
            <h3 className="font-semibold">Ready to save?</h3>
            <p className="text-sm text-gray-500 dark:text-zinc-400">This will save the report and take you to the printable view.</p>
            <Button className="w-full justify-center" onClick={handleSave}>Save & view report →</Button>
            <Button variant="secondary" className="w-full justify-center" onClick={() => setStep('Inspect')}>← Back to inspection</Button>
          </Card>
        </div>
      )}
    </div>
  )
}
