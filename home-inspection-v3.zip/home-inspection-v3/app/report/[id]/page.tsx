'use client'

import { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import type { InspectionReport, InspectionTemplate } from '@/lib/types'
import { getReport } from '@/lib/store'
import { ReportView } from '@/components/report-view'
import { Button, Card } from '@/components/ui'
import templateData from '@/data/apartment-handover.json'

const template = templateData as InspectionTemplate

export default function ReportPage() {
  const params = useParams()
  const [report, setReport] = useState<InspectionReport | null>(null)

  useEffect(() => {
    const r = getReport(params.id as string)
    setReport(r)
  }, [params.id])

  if (!report) return (
    <Card className="text-center py-16">
      <p className="text-2xl mb-3">🔍</p>
      <h2 className="font-semibold text-lg">Report not found</h2>
      <p className="text-sm text-gray-500 dark:text-zinc-400 mt-1">It may have been deleted or not yet saved.</p>
    </Card>
  )

  return (
    <div>
      <div className="flex items-center justify-between gap-4 mb-6 no-print">
        <div>
          <h1 className="text-2xl font-display font-semibold">{report.meta.propertyName}</h1>
          <p className="text-sm text-gray-500 dark:text-zinc-400 mt-0.5">{report.meta.unitNumber} · {report.meta.inspectionDate}</p>
        </div>
        <div className="flex gap-3">
          <Button variant="secondary" onClick={() => window.history.back()}>← Back</Button>
          <Button onClick={() => window.print()}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 14h12v8H6z"/></svg>
            Print report
          </Button>
        </div>
      </div>
      <ReportView report={report} template={template} />
    </div>
  )
}
