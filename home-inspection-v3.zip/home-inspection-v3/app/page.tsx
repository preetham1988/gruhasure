import Link from 'next/link'
import { Button, Card } from '@/components/ui'

const features = [
  { icon: '🏠', title: 'Template-driven',   desc: 'Apartment handover, villa, and resale templates. Add your own via JSON.' },
  { icon: '📋', title: 'Structured checks', desc: '6 sections, 27+ checkpoints, severity levels and inspector comments.' },
  { icon: '📄', title: 'Instant report',    desc: 'Print-ready HTML report with priority findings table and full checklist.' },
  { icon: '🔒', title: 'Client-first',      desc: 'Built for Indian builders and home buyers. Optimised for Bengaluru-style handovers.' },
]

export default function Home() {
  return (
    <div className="space-y-16">
      <section className="pt-10 pb-4">
        <p className="text-sm uppercase tracking-widest text-primary mb-3">CheckMaadsi v3</p>
        <h1 className="text-4xl md:text-5xl font-display font-semibold max-w-2xl leading-tight mb-4">
          Home inspection reports, built for Indian real estate.
        </h1>
        <p className="text-gray-500 dark:text-zinc-400 max-w-xl mb-8">
          Walk through predefined inspection sections, capture defects with severity ratings and comments, then generate a professional printable report for your client in minutes.
        </p>
        <div className="flex flex-wrap gap-3">
          <Link href="/inspection/new">
            <Button>Start new inspection →</Button>
          </Link>
          <Link href="/dashboard">
            <Button variant="secondary">View all reports</Button>
          </Link>
        </div>
      </section>

      <section className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        {features.map(f => (
          <Card key={f.title} className="p-5">
            <span className="text-3xl">{f.icon}</span>
            <h3 className="font-semibold mt-3 mb-1">{f.title}</h3>
            <p className="text-sm text-gray-500 dark:text-zinc-400">{f.desc}</p>
          </Card>
        ))}
      </section>

      <section>
        <Card className="bg-primary/5 dark:bg-primary/10 border-primary/20">
          <h2 className="text-xl font-semibold mb-2">Next steps for production</h2>
          <ul className="text-sm text-gray-600 dark:text-zinc-300 space-y-1 list-disc list-inside">
            <li>Connect a database (Supabase or PlanetScale) and replace <code>lib/store.ts</code></li>
            <li>Add Clerk or NextAuth for inspector login and client access</li>
            <li>Add photo upload per checkpoint (S3 + presigned URLs)</li>
            <li>Add reusable comment templates for common defects</li>
            <li>Add PDF export via Puppeteer or Browserless API</li>
            <li>Add digital signature capture on report completion</li>
          </ul>
        </Card>
      </section>
    </div>
  )
}
