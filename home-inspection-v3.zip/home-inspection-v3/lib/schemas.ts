import { z } from 'zod'

export const propertyMetaSchema = z.object({
  propertyName:  z.string().min(3, 'Property name is required'),
  inspectionDate:z.string().min(1, 'Date is required'),
  clientName:    z.string().min(2, 'Client name is required'),
  clientEmail:   z.string().email('Valid email required'),
  inspectorName: z.string().min(2, 'Inspector name is required'),
  builderName:   z.string().min(2, 'Builder name is required'),
  propertyType:  z.string().min(2),
  unitNumber:    z.string().min(1, 'Unit number is required'),
  floorArea:     z.string().optional().default(''),
  address:       z.string().min(5, 'Address is required'),
  scope:         z.string().min(10, 'Scope description is required'),
})

export type PropertyMetaSchema = z.infer<typeof propertyMetaSchema>

export const findingSchema = z.object({
  status:  z.enum(['ok', 'attention', 'minor', 'major']),
  comment: z.string().optional().default(''),
})
