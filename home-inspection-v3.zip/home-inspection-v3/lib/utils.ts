import { clsx, type ClassValue } from 'clsx'
import type { FindingStatus, FlatFinding, InspectionReport, InspectionTemplate } from './types'

// ─── Class helper ────────────────────────────────────────────────────────────
export function cn(...inputs: ClassValue[]) {
  return clsx(inputs)
}

// ─── Status display maps ─────────────────────────────────────────────────────
export const STATUS_LABELS: Record<FindingStatus, string> = {
  ok: 'OK',
  attention: 'Attention',
  minor: 'Minor',
  major: 'Major',
}

export const STATUS_COLORS: Record<FindingStatus, string> = {
  ok:        'bg-green-100 text-green-800 dark:bg-green-900/40 dark:text-green-300',
  attention: 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300',
  minor:     'bg-orange-100 text-orange-800 dark:bg-orange-900/40 dark:text-orange-300',
  major:     'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300',
}

export const STATUS_ORDER: FindingStatus[] = ['major', 'minor', 'attention', 'ok']

// ─── Derive flat findings from a report + template ───────────────────────────
export function getFlatFindings(
  report: InspectionReport,
  template: InspectionTemplate
): FlatFinding[] {
  const flat: FlatFinding[] = []
  for (const section of template.sections) {
    for (const item of section.items) {
      const f = report.findings[item.key]
      flat.push({
        key: item.key,
        sectionTitle: section.title,
        label: item.label,
        note: item.note,
        status: f?.status ?? 'ok',
        comment: f?.comment ?? '',
      })
    }
  }
  return flat
}

// ─── Count issues by severity ─────────────────────────────────────────────────
export function countBySeverity(report: InspectionReport) {
  const counts: Record<FindingStatus, number> = { ok: 0, attention: 0, minor: 0, major: 0 }
  for (const finding of Object.values(report.findings)) {
    counts[finding.status] = (counts[finding.status] ?? 0) + 1
  }
  return counts
}

// ─── Simple ID generator (replace with uuid in production) ───────────────────
export function generateId() {
  return Math.random().toString(36).slice(2, 10)
}
