// ─── Core domain types ──────────────────────────────────────────────────────

export type FindingStatus = 'ok' | 'attention' | 'minor' | 'major'

export interface TemplateItem {
  key: string
  label: string
  note: string
  severityDefault: FindingStatus
}

export interface TemplateSection {
  id: string
  title: string
  description: string
  items: TemplateItem[]
}

export interface InspectionTemplate {
  templateId: string
  name: string
  propertyTypes: string[]
  sections: TemplateSection[]
}

// ─── Report / finding state ──────────────────────────────────────────────────

export interface FindingRecord {
  status: FindingStatus
  comment: string
  photoUrls?: string[]
}

export interface PropertyMeta {
  propertyName: string
  inspectionDate: string
  clientName: string
  clientEmail: string
  inspectorName: string
  builderName: string
  propertyType: string
  unitNumber: string
  floorArea: string
  address: string
  scope: string
}

export interface InspectionReport {
  id: string
  createdAt: string
  meta: PropertyMeta
  templateId: string
  findings: Record<string, FindingRecord>
}

// ─── Derived display type ────────────────────────────────────────────────────

export interface FlatFinding {
  key: string
  sectionTitle: string
  label: string
  note: string
  status: FindingStatus
  comment: string
}
