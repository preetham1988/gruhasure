// In a real Next.js app this would be replaced with a database or server action.
// For now it uses in-memory session storage (localStorage in browser).
// NOTE: localStorage is blocked in sandboxed iframes; use in real deployments only.

import type { InspectionReport } from './types'
import { generateId } from './utils'

const STORAGE_KEY = 'checkmaadsi_reports'

export function getAllReports(): InspectionReport[] {
  if (typeof window === 'undefined') return []
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? (JSON.parse(raw) as InspectionReport[]) : []
  } catch {
    return []
  }
}

export function getReport(id: string): InspectionReport | null {
  return getAllReports().find(r => r.id === id) ?? null
}

export function saveReport(report: Omit<InspectionReport, 'id' | 'createdAt'>): InspectionReport {
  const full: InspectionReport = {
    ...report,
    id: generateId(),
    createdAt: new Date().toISOString(),
  }
  const all = getAllReports()
  localStorage.setItem(STORAGE_KEY, JSON.stringify([...all, full]))
  return full
}

export function updateReport(id: string, patch: Partial<InspectionReport>): InspectionReport | null {
  const all = getAllReports()
  const idx = all.findIndex(r => r.id === id)
  if (idx === -1) return null
  all[idx] = { ...all[idx], ...patch }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(all))
  return all[idx]
}

export function deleteReport(id: string): void {
  const all = getAllReports().filter(r => r.id !== id)
  localStorage.setItem(STORAGE_KEY, JSON.stringify(all))
}
