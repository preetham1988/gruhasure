'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'

const links = [
  { href: '/',           label: 'Home' },
  { href: '/dashboard',  label: 'Reports' },
  { href: '/inspection/new', label: 'New inspection' },
]

export function Nav() {
  const path = usePathname()
  return (
    <header className="sticky top-0 z-50 border-b border-gray-200 dark:border-zinc-800 bg-white/80 dark:bg-zinc-950/80 backdrop-blur-md">
      <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between gap-4">
        <Link href="/" className="flex items-center gap-2.5 font-semibold">
          <span className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-white text-sm">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M3 10.5 12 3l9 7.5V21H3z"/><path d="M9 21v-6h6v6"/>
            </svg>
          </span>
          CheckMaadsi
        </Link>
        <nav className="flex items-center gap-1">
          {links.map(l => (
            <Link key={l.href} href={l.href} className={cn(
              'px-4 py-2 rounded-full text-sm font-medium transition-colors',
              path === l.href ? 'bg-primary/10 text-primary-hover dark:text-primary' : 'hover:bg-surface-2 dark:hover:bg-zinc-800 text-gray-600 dark:text-zinc-400'
            )}>{l.label}</Link>
          ))}
        </nav>
      </div>
    </header>
  )
}
