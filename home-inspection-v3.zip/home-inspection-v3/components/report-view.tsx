import type { InspectionReport, InspectionTemplate } from '@/lib/types'
import { getFlatFindings, STATUS_ORDER, STATUS_LABELS, countBySeverity } from '@/lib/utils'

export function ReportView({ report, template }: { report: InspectionReport; template: InspectionTemplate }) {
  const { meta } = report
  const flat = getFlatFindings(report, template)
  const issues = flat.filter(f => f.status !== 'ok').sort((a, b) => STATUS_ORDER.indexOf(a.status) - STATUS_ORDER.indexOf(b.status))
  const counts = countBySeverity(report)

  return (
    <div className="bg-white text-gray-900 rounded-2xl shadow-xl p-8 print:shadow-none print:rounded-none print:p-0 space-y-8">
      {/* Header */}
      <header className="flex flex-col md:flex-row justify-between gap-6 pb-6 border-b-2 border-gray-200">
        <div>
          <p className="text-xs uppercase tracking-widest text-gray-400">Home inspection report</p>
          <h1 className="text-3xl font-display font-semibold mt-1">{meta.propertyName}</h1>
          <p className="text-sm text-gray-500 mt-1">{meta.unitNumber} — {meta.address}</p>
        </div>
        <div className="text-sm space-y-1 shrink-0">
          <p><span className="font-semibold">Date:</span> {meta.inspectionDate}</p>
          <p><span className="font-semibold">Client:</span> {meta.clientName} ({meta.clientEmail})</p>
          <p><span className="font-semibold">Inspector:</span> {meta.inspectorName}</p>
          <p><span className="font-semibold">Builder:</span> {meta.builderName}</p>
          {meta.floorArea && <p><span className="font-semibold">Floor area:</span> {meta.floorArea}</p>}
        </div>
      </header>

      {/* Scope */}
      <section>
        <h2 className="text-lg font-semibold mb-1">Scope of inspection</h2>
        <p className="text-sm text-gray-600">{meta.scope}</p>
      </section>

      {/* Issue count */}
      <section>
        <h2 className="text-lg font-semibold mb-3">Issue summary</h2>
        <div className="grid grid-cols-4 gap-3">
          {(['major','minor','attention','ok'] as const).map(s => (
            <div key={s} className="border rounded-xl p-3 text-center">
              <span className="text-2xl font-bold">{counts[s] ?? 0}</span>
              <p className="text-xs text-gray-500 capitalize mt-0.5">{s}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Priority findings */}
      <section>
        <h2 className="text-lg font-semibold mb-3">Priority findings</h2>
        {issues.length === 0 ? (
          <p className="text-sm text-gray-400">No issues found. All checkpoints marked OK.</p>
        ) : (
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className="bg-gray-50">
                <th className="border border-gray-200 p-2 text-left">Severity</th>
                <th className="border border-gray-200 p-2 text-left">Section</th>
                <th className="border border-gray-200 p-2 text-left">Checkpoint</th>
                <th className="border border-gray-200 p-2 text-left">Comment</th>
              </tr>
            </thead>
            <tbody>
              {issues.map(f => (
                <tr key={f.key}>
                  <td className="border border-gray-200 p-2 font-semibold">{STATUS_LABELS[f.status]}</td>
                  <td className="border border-gray-200 p-2">{f.sectionTitle}</td>
                  <td className="border border-gray-200 p-2">{f.label}</td>
                  <td className="border border-gray-200 p-2">{f.comment || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      {/* Full checklist */}
      <section>
        <h2 className="text-lg font-semibold mb-3">Full checklist</h2>
        {template.sections.map(section => (
          <div key={section.id} className="mb-5">
            <h3 className="font-semibold text-base mb-2">{section.title}</h3>
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-gray-50">
                  <th className="border border-gray-200 p-2 text-left w-[40%]">Checkpoint</th>
                  <th className="border border-gray-200 p-2 text-left w-[10%]">Status</th>
                  <th className="border border-gray-200 p-2 text-left">Comment</th>
                </tr>
              </thead>
              <tbody>
                {section.items.map(item => {
                  const f = report.findings[item.key]
                  return (
                    <tr key={item.key}>
                      <td className="border border-gray-200 p-2">{item.label}</td>
                      <td className="border border-gray-200 p-2 font-semibold">{STATUS_LABELS[f?.status ?? 'ok']}</td>
                      <td className="border border-gray-200 p-2">{f?.comment || '—'}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        ))}
      </section>

      <footer className="border-t pt-4 text-xs text-gray-400">
        Report generated by CheckMaadsi v3 · {new Date().toLocaleDateString('en-IN')}
      </footer>
    </div>
  )
}
