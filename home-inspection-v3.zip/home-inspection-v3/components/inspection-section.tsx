'use client'

import { useState } from 'react'
import type { TemplateSection, FindingRecord, FindingStatus } from '@/lib/types'
import { Card, Badge, StatusGroup, Textarea } from './ui'
import { cn } from '@/lib/utils'

interface InspectionSectionProps {
  section: TemplateSection
  findings: Record<string, FindingRecord>
  onChange: (key: string, patch: Partial<FindingRecord>) => void
}

export function InspectionSectionCard({ section, findings, onChange }: InspectionSectionProps) {
  const [open, setOpen] = useState(true)

  const issues = section.items.filter(i => (findings[i.key]?.status ?? 'ok') !== 'ok')
  const sectionStatus: FindingStatus =
    issues.some(i => findings[i.key]?.status === 'major')     ? 'major' :
    issues.some(i => findings[i.key]?.status === 'minor')     ? 'minor' :
    issues.some(i => findings[i.key]?.status === 'attention') ? 'attention' : 'ok'

  return (
    <Card className="p-0 overflow-hidden">
      <button
        className="w-full flex items-center justify-between gap-4 px-6 py-4 text-left"
        onClick={() => setOpen(o => !o)}
      >
        <div>
          <h3 className="font-semibold">{section.title}</h3>
          <p className="text-sm text-gray-500 dark:text-zinc-400">{section.description}</p>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <Badge status={sectionStatus} />
          <span className={cn('text-gray-400 transition-transform', open && 'rotate-180')}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 9l6 6 6-6"/></svg>
          </span>
        </div>
      </button>

      {open && (
        <div className="border-t border-gray-100 dark:border-zinc-800 divide-y divide-gray-100 dark:divide-zinc-800">
          {section.items.map(item => {
            const f = findings[item.key] ?? { status: 'ok' as FindingStatus, comment: '' }
            return (
              <div key={item.key} className="px-6 py-4 grid md:grid-cols-2 gap-4">
                <div>
                  <p className="font-semibold text-sm">{item.label}</p>
                  <p className="text-xs text-gray-500 dark:text-zinc-400 mt-0.5">{item.note}</p>
                  <div className="mt-3">
                    <StatusGroup
                      name={item.key}
                      value={f.status}
                      onChange={v => onChange(item.key, { status: v })}
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-500 dark:text-zinc-400">Inspector comment</label>
                  <Textarea
                    className="mt-1.5"
                    placeholder="Add notes, dimensions, or recommended action…"
                    value={f.comment ?? ''}
                    onChange={e => onChange(item.key, { comment: e.target.value })}
                  />
                </div>
              </div>
            )
          })}
        </div>
      )}
    </Card>
  )
}
