// Shared primitive UI components — replace with shadcn/ui in production

import React from 'react'
import { cn, STATUS_COLORS, STATUS_LABELS } from '@/lib/utils'
import type { FindingStatus } from '@/lib/types'

// ─── Badge ────────────────────────────────────────────────────────────────────
export function Badge({ status }: { status: FindingStatus }) {
  return (
    <span className={cn('inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-bold', STATUS_COLORS[status])}>
      {STATUS_LABELS[status]}
    </span>
  )
}

// ─── Button ───────────────────────────────────────────────────────────────────
type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'primary' | 'secondary' | 'ghost'
}
export function Button({ variant = 'primary', className, children, ...props }: ButtonProps) {
  return (
    <button
      className={cn(
        'inline-flex items-center gap-2 rounded-full font-semibold transition-colors min-h-[44px] px-5 py-2',
        variant === 'primary'   && 'bg-primary text-white hover:bg-primary-hover',
        variant === 'secondary' && 'bg-surface-2 border border-gray-200 dark:border-zinc-700 hover:bg-surface-offset',
        variant === 'ghost'     && 'hover:bg-surface-2',
        className
      )}
      {...props}
    >
      {children}
    </button>
  )
}

// ─── Card ─────────────────────────────────────────────────────────────────────
export function Card({ className, children }: { className?: string; children: React.ReactNode }) {
  return (
    <div className={cn('rounded-2xl border border-gray-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-sm p-6', className)}>
      {children}
    </div>
  )
}

// ─── Input ────────────────────────────────────────────────────────────────────
export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  ({ className, ...props }, ref) => (
    <input
      ref={ref}
      className={cn('w-full rounded-xl border border-gray-200 dark:border-zinc-700 bg-surface-2 dark:bg-zinc-800 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40', className)}
      {...props}
    />
  )
)
Input.displayName = 'Input'

// ─── Textarea ─────────────────────────────────────────────────────────────────
export const Textarea = React.forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement>>(
  ({ className, ...props }, ref) => (
    <textarea
      ref={ref}
      className={cn('w-full rounded-xl border border-gray-200 dark:border-zinc-700 bg-surface-2 dark:bg-zinc-800 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 resize-vertical min-h-[80px]', className)}
      {...props}
    />
  )
)
Textarea.displayName = 'Textarea'

// ─── Select ───────────────────────────────────────────────────────────────────
export const Select = React.forwardRef<HTMLSelectElement, React.SelectHTMLAttributes<HTMLSelectElement>>(
  ({ className, children, ...props }, ref) => (
    <select
      ref={ref}
      className={cn('w-full rounded-xl border border-gray-200 dark:border-zinc-700 bg-surface-2 dark:bg-zinc-800 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40', className)}
      {...props}
    >
      {children}
    </select>
  )
)
Select.displayName = 'Select'

// ─── FormField ────────────────────────────────────────────────────────────────
export function FormField({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div className="grid gap-1.5">
      <label className="text-sm font-semibold">{label}</label>
      {children}
      {error && <p className="text-xs text-red-600 dark:text-red-400">{error}</p>}
    </div>
  )
}

// ─── StatusGroup ──────────────────────────────────────────────────────────────
export function StatusGroup({
  value, onChange, name,
}: { value: FindingStatus; onChange: (v: FindingStatus) => void; name: string }) {
  const options: FindingStatus[] = ['ok', 'attention', 'minor', 'major']
  return (
    <div className="flex flex-wrap gap-2">
      {options.map(opt => (
        <label key={opt} className={cn(
          'flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold cursor-pointer transition-colors select-none',
          value === opt
            ? 'border-primary bg-primary/10 text-primary-hover dark:text-primary'
            : 'border-gray-200 dark:border-zinc-700 hover:bg-surface-2'
        )}>
          <input
            type="radio" name={name} value={opt} checked={value === opt}
            onChange={() => onChange(opt)} className="sr-only"
          />
          {STATUS_LABELS[opt]}
        </label>
      ))}
    </div>
  )
}
