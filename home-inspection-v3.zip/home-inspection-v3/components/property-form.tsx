'use client'

import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { propertyMetaSchema, type PropertyMetaSchema } from '@/lib/schemas'
import { Card, Button, Input, Textarea, Select, FormField } from './ui'

interface PropertyFormProps {
  defaultValues?: Partial<PropertyMetaSchema>
  onSubmit: (data: PropertyMetaSchema) => void
}

export function PropertyForm({ defaultValues, onSubmit }: PropertyFormProps) {
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<PropertyMetaSchema>({
    resolver: zodResolver(propertyMetaSchema),
    defaultValues: {
      propertyName: '', inspectionDate: '', clientName: '', clientEmail: '',
      inspectorName: '', builderName: '', propertyType: 'Apartment handover',
      unitNumber: '', floorArea: '', address: '', scope: '',
      ...defaultValues,
    },
  })

  return (
    <Card>
      <h2 className="text-xl font-semibold mb-1">Property details</h2>
      <p className="text-sm text-gray-500 dark:text-zinc-400 mb-6">This metadata appears in the report header.</p>
      <form onSubmit={handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField label="Property / project name" error={errors.propertyName?.message}>
          <Input placeholder="e.g. Sobha Dream Acres – Tower 15" {...register('propertyName')} />
        </FormField>
        <FormField label="Unit number" error={errors.unitNumber?.message}>
          <Input placeholder="e.g. Flat 1403" {...register('unitNumber')} />
        </FormField>
        <FormField label="Inspection date" error={errors.inspectionDate?.message}>
          <Input type="date" {...register('inspectionDate')} />
        </FormField>
        <FormField label="Floor area (optional)">
          <Input placeholder="e.g. 1380 sq.ft" {...register('floorArea')} />
        </FormField>
        <FormField label="Client name" error={errors.clientName?.message}>
          <Input placeholder="e.g. Rahul Verma" {...register('clientName')} />
        </FormField>
        <FormField label="Client email" error={errors.clientEmail?.message}>
          <Input type="email" placeholder="rahul@email.com" {...register('clientEmail')} />
        </FormField>
        <FormField label="Inspector name" error={errors.inspectorName?.message}>
          <Input placeholder="e.g. Arjun Singh" {...register('inspectorName')} />
        </FormField>
        <FormField label="Builder" error={errors.builderName?.message}>
          <Input placeholder="e.g. Sobha Ltd." {...register('builderName')} />
        </FormField>
        <FormField label="Property type" error={errors.propertyType?.message}>
          <Select {...register('propertyType')}>
            <option>Apartment handover</option>
            <option>Villa inspection</option>
            <option>Resale apartment</option>
            <option>Snagging inspection</option>
          </Select>
        </FormField>
        <div className="md:col-span-2">
          <FormField label="Address" error={errors.address?.message}>
            <Textarea placeholder="Full property address..." rows={2} {...register('address')} />
          </FormField>
        </div>
        <div className="md:col-span-2">
          <FormField label="Inspection scope" error={errors.scope?.message}>
            <Textarea placeholder="Describe scope of inspection..." rows={3} {...register('scope')} />
          </FormField>
        </div>
        <div className="md:col-span-2 flex justify-end pt-2">
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? 'Saving…' : 'Save & continue →'}
          </Button>
        </div>
      </form>
    </Card>
  )
}
