import type { InspectionReport, InspectionTemplate } from '@/lib/types'
import { getFlatFindings, STATUS_ORDER, countBySeverity } from '@/lib/utils'
import { Badge, Card } from './ui'

export function SummaryPanel({ report, template }: { report: InspectionReport; template: InspectionTemplate }) {
  const flat = getFlatFindings(report, template)
  const issues = flat.filter(f => f.status !== 'ok').sort((a, b) => STATUS_ORDER.indexOf(a.status) - STATUS_ORDER.indexOf(b.status))
  const counts = countBySeverity(report)

  return (
    <Card>
      <h2 className="text-xl font-semibold mb-1">Summary</h2>
      <p className="text-sm text-gray-500 dark:text-zinc-400 mb-5">Issues across all sections, sorted by priority.</p>
      <div className="grid grid-cols-4 gap-3 mb-6">
        {(['major','minor','attention','ok'] as const).map(s => (
          <div key={s} className="rounded-xl bg-surface-2 dark:bg-zinc-800 p-3 text-center">
            <span className="text-2xl font-bold">{counts[s] ?? 0}</span>
            <p className="text-xs text-gray-500 dark:text-zinc-400 mt-0.5 capitalize">{s}</p>
          </div>
        ))}
      </div>
      {issues.length === 0 ? (
        <p className="text-sm text-gray-400 dark:text-zinc-500 text-center py-8">No issues captured yet. All checkpoints are marked OK.</p>
      ) : (
        <div className="grid gap-2">
          {issues.map(f => (
            <div key={f.key} className="flex gap-3 items-start rounded-xl border border-gray-100 dark:border-zinc-800 p-3">
              <Badge status={f.status} />
              <div>
                <p className="text-sm font-semibold">{f.label}</p>
                <p className="text-xs text-gray-500 dark:text-zinc-400">{f.sectionTitle}{f.comment ? ` — ${f.comment}` : ''}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  )
}
