import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Newsreader', 'Georgia', 'serif'],
      },
      colors: {
        primary: {
          DEFAULT: '#01696f',
          hover: '#0c4e54',
          light: '#d5e4e1',
        },
        surface: {
          DEFAULT: '#faf9f6',
          2: '#f1eeea',
          offset: '#ebe7e1',
        },
      },
    },
  },
  plugins: [],
}
export default config
